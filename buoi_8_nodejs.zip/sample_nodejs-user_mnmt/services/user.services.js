const db = require("../database/connection");

const getAllUsers = async () =>{
    //your code goes here
}


const getUserById = async (id) =>{
    //your code goes here
}

const createUser = async (user) =>{
    //your code goes here
}

const updateUser = async (id, user) =>{
    //your code goes here
}

const deleteUser = async (id) =>{
    //your code goes here
}

module.exports = {
    getAllUsers,
    getUserById,
    createUser,
    updateUser,
    deleteUser
}


