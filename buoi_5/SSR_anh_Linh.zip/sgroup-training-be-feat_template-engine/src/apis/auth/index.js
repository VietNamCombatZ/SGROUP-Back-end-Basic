import authRoute from './auth.router.js';
import authController from './auth.controller.js';
import authService from './auth.service.js';

export {
    authRoute,
    authController,
    authService
}